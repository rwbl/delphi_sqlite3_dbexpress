; B4A Project ropmemo
;
; Create Table
;
DROP TABLE IF EXISTS Memos
CREATE TABLE Memos (ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, Subject TEXT NOT NULL, Date Text, Category Text, Keywords Text, Memo Text);
;
; Insert Data
;
INSERT INTO Memos (ID, Subject, Date, Category, Keywords, Memo) VALUES (NULL, 'Memo1', '03.04.2013', 'A', '', 'Inhalt Memo1');
INSERT INTO Memos (ID, Subject, Date, Category, Keywords, Memo) VALUES (NULL, 'Memo2', '01.05.2013', 'B', '', 'Inhalt Memo2');
INSERT INTO Memos (ID, Subject, Date, Category, Keywords, Memo) VALUES (NULL, 'Memo3', '02.05.2013', 'A', '', 'Inhalt Memo3');
INSERT INTO Memos (ID, Subject, Date, Category, Keywords, Memo) VALUES (NULL, 'Memo4', '09.05.2013', 'B', '', 'Inhalt Memo4');
