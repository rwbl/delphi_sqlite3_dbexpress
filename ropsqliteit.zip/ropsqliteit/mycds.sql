; SQLite Project mycds
;
; Create the tables
;
create table Artists (ArtistID INTEGER PRIMARY KEY, ArtistName TEXT);
create table CDs (CDID INTEGER PRIMARY KEY,ArtistID INTEGER NOT NULL,Title TEXT NOT NULL,Date TEXT);
;
; Insert some data
;
insert into Artists (ArtistID,ArtistName) values (NULL,'Peter Gabriel');
insert into Artists (ArtistID,ArtistName) values (NULL,'Bruce Hornsby');
insert into Artists (ArtistID,ArtistName) values (NULL,'Lyle Lovett');
insert into Artists (ArtistID,ArtistName) values (NULL,'Beach Boys');
;
insert into CDs (CDID,ArtistID,Title,Date) values (NULL,1,'So','1984');
insert into CDs (CDID,ArtistID,Title,Date) values (NULL,1,'Us','1992');
insert into CDs (CDID,ArtistID,Title,Date) values (NULL,2,'The Way It Is','1986');
insert into CDs (CDID,ArtistID,Title,Date) values (NULL,2,'Scenes from the Southside','1990');
insert into CDs (CDID,ArtistID,Title,Date) values (NULL,1,'Security','1990');
insert into CDs (CDID,ArtistID,Title,Date) values (NULL,3,'Joshua Judges Ruth','1992');
insert into CDs (CDID,ArtistID,Title,Date) values (NULL,4,'Pet Sounds','1966');;
;
; SELECT
;
select * from Artists;     
select * from CDs;     
SELECT Title AS AlbumName FROM CDs;     
SELECT Title FROM CDs WHERE Date>=1990 ORDER BY Title;     
SELECT Date FROM CDs;     
SELECT DISTINCT Date FROM CDs;     
SELECT Title FROM CDs GROUP BY ArtistID;     
; 
;Selecting from two tables
;
SELECT t1.ArtistName,CDs.Title FROM Artists t1, CDs WHERE t1.ArtistID=CDs.ArtistID  
;
;Update
;
insert into Artists (ArtistID,ArtistName) values (NULL,'Supernatural');
UPDATE Artists SET ArtistName ='Santana' WHERE ArtistID=5;     
insert into CDs (CDID,ArtistID,Title,Date) values (NULL,5,'Supernatural','1999');     
;
;Delete
;
select * FROM CDs WHERE Title LIKE 'Super%';     
DELETE FROM CDs WHERE Title LIKE 'Super%';     
Select * From CDs WHERE Title LIKE 'Super%';     
;
;
;


