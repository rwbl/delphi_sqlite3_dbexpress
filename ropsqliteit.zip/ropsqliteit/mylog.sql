drop table if exists mylog;
create table mylog (id int, log text);
insert into mylog (id, log) values(1, "moin");
insert into mylog (id, log) values(2, "moin");

select * from mylog;

