; SQLiteIt Befehlsdatei (c) 2013 Robert W.B. Linn, Pinneberg, Germany
; Erstelllt werden die Tabellen Autoren, Buecher und Log.
; Beispieldatens�tze werden geladen.
; Hinweis: Jede enth�lt ein SQL Befehl.
; Version: 20130328
;
DROP TABLE IF EXISTS Autoren;
CREATE TABLE Autoren (AutorID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, Name VARCHAR(40), Beschreibung VARCHAR(255), Homepage VARCHAR(100));

DROP TABLE IF EXISTS Buecher;
CREATE TABLE Buecher (BuchID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, Titel VARCHAR(100) NOT NULL, AutorID INTEGER, ISBN VARCHAR(20));

DROP TABLE IF EXISTS Log;
CREATE TABLE Log (LogID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, Datum VARCHAR(20) NOT NULL, Info VARCHAR(255) NOT NULL);

DROP TRIGGER IF EXISTS Buecher_I;
CREATE TRIGGER Buecher_I AFTER INSERT ON Buecher BEGIN INSERT INTO Log(Datum, Info) VALUES (DATETIME('now'), 'Neu: ' || new.Titel);END;

DROP TRIGGER IF EXISTS Buecher_U;
CREATE TRIGGER Buecher_U AFTER UPDATE ON Buecher BEGIN INSERT INTO Log(Datum, Info)  VALUES (DATETIME('now'), 'Ge�ndert: ' || old.Titel || ' auf ' || new.Titel);END;

DROP TRIGGER IF EXISTS Buecher_D;
CREATE TRIGGER Buecher_D AFTER DELETE ON Buecher BEGIN INSERT INTO Log(Datum, Info)  VALUES (DATETIME('now'), 'Gel�scht: ' || old.Titel);END;

INSERT INTO Autoren (AutorID,Name) VALUES (NULL,'Hannes Nygaard');
INSERT INTO Autoren (AutorID,Name) VALUES (NULL,'Derek Meister');
INSERT INTO Autoren (AutorID,Name) VALUES (NULL,'Adler Olsen');

INSERT INTO Buecher (BuchID,Titel,AutorID,ISBN) VALUES (NULL,'Schwere Wetter',1,'978-3897059207');
INSERT INTO Buecher (BuchID,Titel,AutorID,ISBN) VALUES (NULL,'Nebelfront',1,'978-3954510269');
INSERT INTO Buecher (BuchID,Titel,AutorID,ISBN) VALUES (NULL,'Flutgrab',2,'978-3442376476');
INSERT INTO Buecher (BuchID,Titel,AutorID,ISBN) VALUES (NULL,'Knochenwald',2,'978-3442379323');
INSERT INTO Buecher (BuchID,Titel,AutorID,ISBN) VALUES (NULL,'Verachtung',3,'978-3423280020');
INSERT INTO Buecher (BuchID,Titel,AutorID,ISBN) VALUES (NULL,'Erl�sung',3,'978-3423248525');

SELECT Autoren.Name,Buecher.Titel FROM Autoren, Buecher WHERE Autoren.AutorID=Buecher.AutorID
