-ropSQLiteIt
Copyright (c) 2013 by Robert W.B. Linn, Pinneberg, Germany (http://www.rwblinn.de).
The program is made available under the terms of the Mozilla Public License 2.0 (https://www.mozilla.org/MPL/2.0/).

-Download
Zu finden unter SQLiteIt in <!file://delphi/tutorials/ropdelphisqliteprojects.zip|Open Source Beispiele>

-Beschreibung
Ein SQLite Befehlsinterpreter = SQL Befehle ausf�hren.
Das SQL Befehlsergebnis wird in einem Logfenster gezeigt.
Zus�tzlich wird das Ergebnis eines SELECT Befehls in eine Tabelle gezeigt.

-Installation
Entpacke ropdelphisqliteprojects.zip.
Delphi starten und ropsqliteit.dproj aus dem Verzeichnis ropSQLiteIt laden.

-Hinweise
Ideen, Verbessrungen bitte per E-Mail an robert@rwblinn.de.

-Historie
(+) Neu (*) Verbessert (-) Entfernt (!) Notizen
20130819
(*) Verschiedene Verbesserungen

20130329
(+) Datenbank schlie�en
(*) Datenbank �ffnen Filter erweitert
(*) Bearbeiten Men� Reihenfolge ge�ndert

20130318
(+) Erste Version
