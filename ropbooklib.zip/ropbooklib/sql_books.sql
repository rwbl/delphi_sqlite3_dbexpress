CREATE TABLE "books" ("_id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL  UNIQUE , "title" TEXT NOT NULL , "author" TEXT, "isbn" TEXT, "description" TEXT, "category" TEXT);
CREATE VIEW "viewallbooks" AS select * from books;
